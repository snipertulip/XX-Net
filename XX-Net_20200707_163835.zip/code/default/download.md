
## 下载(Download)：
稳定版(Stable version 4.0.5)：  
[Windows 版下载](https://github.com/XX-net/XX-Net/releases/download/4.0.5/XX-Net-windows-4.0.5.7z)   
[Mac/Linux 版下载](https://github.com/XX-net/XX-Net/archive/4.0.5.zip)  

测试版(Test version 4.1.0)：  
[Windows 版下载](https://github.com/XX-net/XX-Net/releases/download/4.1.0/XX-Net-windows-4.1.0.7z)   
[Mac/Linux 版下载](https://github.com/XX-net/XX-Net/archive/4.1.0.zip)  


Android:  
集成fqrouter和XX-Net，推荐：  
https://github.com/XndroidDev/Xndroid/releases
