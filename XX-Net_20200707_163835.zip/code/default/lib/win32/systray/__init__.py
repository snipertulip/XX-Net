# infi.systray

from .traybar import SysTrayIcon
