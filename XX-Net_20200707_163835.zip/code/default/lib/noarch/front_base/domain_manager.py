

class DomainManagerBase(object):
    def get_host_sni(self):
        return "", ""