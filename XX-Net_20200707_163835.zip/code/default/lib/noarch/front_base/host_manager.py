import random

class HostManagerBase(object):

    def get_sni_host(self, ip):
        return "", ""
