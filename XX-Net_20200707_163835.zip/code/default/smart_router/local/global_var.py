
running = True

gae_proxy = None
x_tunnel = None

config = None
ip_region = None
gfwlist = None
domain_cache = None
ip_cache = None
user_rules = None

connect_manager = None
pipe_socks = None
dns_client = None

proxy_server = None
dns_srv = None

gae_proxy_listen_port = None
x_tunnel_socks_port = None
